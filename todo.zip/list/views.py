from ast import Return
from email import message
from turtle import title
from django.shortcuts import render,redirect
from django.http import HttpResponse 
from multiprocessing import context
from .models import Text
from django.contrib.auth import logout,authenticate,login
from django.contrib import messages

def todo(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            tit = request.POST['title'] 
            input = request.POST['task']
            Text.objects.create(title = tit , task=input)
            messages.success(request,'Note taking successfully.....')
            return redirect('todo')
        obj = Text.objects.all()
        context = {'texts': obj ,'login':True}
        return render(request, 'todo_list.html', context)
    else:
        return render(request, 'todo_list.html')


def delete_task(request,pk):
    obj = Text.objects.get(id=pk)
    obj.delete()
    return redirect('todo')


def update_task(request,pk):
    obj =Text.objects.get(id=pk)
    pre_task= obj.task
    pre_title = obj.title
    if request.method=="POST":
        new_task = request.POST['task']
        new_title =request.POST['title']
        obj.task= new_task 
        obj.title=new_title
        obj.save()
        return redirect('todo')
    obj = Text.objects.all()
    context ={'texts':obj,'task':pre_task,'title':pre_title}
    return render(request,'todo_list.html',context)

def logout_user(request):
    logout(request)
    return redirect('login')
def login_user(request):
    if request.method=="POST":
        username= request.POST['user']
        password= request.POST['pass']
        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('todo')
        else:
            mes = 'please enter valid username and password'
            context ={'message':mes}
            return render(request,'index.html',context)
    return render(request,'index.html')



    

