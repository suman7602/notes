from django.urls import path
from  . import views
urlpatterns =[
    path('',views.todo , name= 'todo'),
    path('delete-task/<str:pk>',views.delete_task,name='delete-task'),
    path('update-task/<str:pk>',views.update_task,name='update-task'),
    path('logout',views.logout_user,name='logout'),
    path ('login',views.login_user,name='login'),
]
